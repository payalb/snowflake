
-- Command Line

snowsql --Install downloaded version of SnowSQL

cd .snowsql

ls

notepad config -- add account locator, cloud provider region, username & password to config file

snowsql

-- SnowSQL Command Line Tool

SELECT CURRENT_VERSION();

